<?php
	function db(){
		
		mysqli_connect("localhost","root","","myshop");
		
	}

?>