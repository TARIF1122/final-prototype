
<html>
	<head>
		<title>payment option</title>
	</head>
	<body>
	<?php
		include("includes/db.php");
		$con = mysqli_connect("localhost","root","","myshop");
		include("functions/functions.php");
	?>
	
<div align="center">

<h2>Payment Options for you<h2>
<?php
$ip=getRealIpAddr();
$get_customer="select * from customer where customer_ip='$ip'";

$run_customer=mysqli_query($con,$get_customer);
$customer=mysqli_fetch_array($run_customer);
customer_id=$customer['customer_id'];
?>
<b>Pay with <a href="http://www.paypal.com"> </b><img src="images/paypal.png" alt="paypal pic download" width="50" height="50"></a><b>or</b><a href="order.php?c_id=<?php echo $customer_id;?>">PAYOFFLINE</a></b>


</div>